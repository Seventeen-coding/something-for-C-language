#ifndef _OLE2VER_H
#define _OLE2VER_H
#if __GNUC__ >=3
#pragma GCC system_header
#endif
#define rmm 23
#define rup 639
#endif
